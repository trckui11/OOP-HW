// 216303990 Arbel Feldman

package Game;

import biuoop.DrawSurface;

import java.awt.Color;

/**
 * The background of the Wide Easy level.
 */
public class WideEasyBackground implements Sprite {
    @Override
    public void drawOn(DrawSurface d) {
        // background:
        d.setColor(Color.WHITE);
        d.fillRectangle(0, 0, GameLevel.SCREEN_WIDTH, GameLevel.SCREEN_HEIGHT);
        // rays:
        d.setColor(Color.YELLOW);
        for (int i = 5; i < 700; i += 5) {
            d.drawLine(120, 120, i, 250);
        }
        // sun:
        d.setColor(Color.RED);
        d.fillCircle(120, 120, 66);
        d.setColor(Color.ORANGE);
        d.fillCircle(120, 120, 60);
        d.setColor(Color.YELLOW);
        d.fillCircle(120, 120, 50);


    }

    @Override
    public void timePassed() {

    }

    @Override
    public void addToGame(GameLevel g) {
        g.addSprite(this);
    }
}
